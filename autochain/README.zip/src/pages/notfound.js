import React from "react";


class NotFound extends React.Component {
  


	render() {


		return (
                
               <div className="project-create-page">

                


                  <div className="page-content no-banner">
         
                      <div className="container">
                          <div className="row home-row-1 padding-75">
                            

                            <div className="col-12 col-lg-8">
                     
                            

                                <h1>You are lost !</h1>
                           
                           </div> 


                     
                          </div>
                        </div>

                </div>
           </div> 
  

		);

	}

}

export default NotFound;

