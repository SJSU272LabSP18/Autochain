Freelancer Application lab 2 for CMPE 273


## 1. Start Producer

> Open variables.env , change mongo db details in DATABASE
> npm install
> To run front , node ./bin/www , available @ http://localhost:3010/

## 2. Start Kafka with regular settings

## 3. Start Consumer

> Open variables.env , change mongo db details in DATABASE
> npm install
> To run front , node ./bin/www , available @ http://localhost:3001/

Kafka Topics - 

userControllerIndex
userControllerCreate
userControllerShow
userControllerShow
userControllerUpdate
userControllerDelete
projectControllerRelevant
projectControllerBidprojects
projectControllerIndex
projectControllerCreate
projectControllerShow
projectControllerUpdate
projectControllerSubmitproject
projectControllerFinalize
projectControllerDelete
bidControllerIndex
bidControllerCreate
bidControllerShow
bidControllerUpdate
bidControllerDelete
transactionControllerIndex
transactionControllerCreate
transactionControllerWithdraw
utilityControllerAjax